import java.util.Collections;

public class Board {
    private final Graph complete;

    public Board(int size) {
        // create the complete graph
        this.complete = new Graph(size);
        // shuffle its edges
        Collections.shuffle(complete.getEdges());
    }

    public synchronized Edge extract() {
        Edge edge = complete.getEdges().getFirst();
        complete.getEdges().removeFirst();
        return edge;
    }

    public boolean isEmpty() {
        return complete.getEdges().isEmpty();
    }

    public Graph getComplete() {
        return complete;
    }
}

