import java.util.LinkedList;
import java.util.List;

public class Graph {
    private List<Edge> edges = new LinkedList<>();
    private int numberOfNodes;

    public void add(Edge edge) {
        edges.add(edge);
    }

    public Graph() {
        this.numberOfNodes = 0;
        initGraph(numberOfNodes);
    }

    public Graph(int numberOfNodes) {
        this.numberOfNodes = numberOfNodes;
        initGraph(numberOfNodes);
    }

    /**
     * set links between each node
     *
     * @param numberOfNodes
     */
    public void initGraph(int numberOfNodes) {
        int i, j;
        for (i = 1; i < numberOfNodes; i++)
            for (j = i + 1; j <= numberOfNodes; j++)
                edges.add(new Edge(i, j));
    }

    public int getNumberOfNodes() {
        return numberOfNodes;
    }

    public LinkedList<Edge> getEdges() {
        return (LinkedList<Edge>) edges;
    }

    public void setEdges(LinkedList<Edge> edges) {
        this.edges = edges;
    }

    public void setNumberOfNodes(int numberOfNodes) {
        this.numberOfNodes = numberOfNodes;
    }

    /*public Edge pollFirst() {
       return edges.get(0);
    }*/

    public boolean isSpanningTree() {
        return DFS.isTree(this);
    }

    @Override
    public String toString() {
        String toPrint = "";
        for (Edge edge : edges) {
            toPrint = toPrint.concat(edge.getEdgeNumber() + ": " + String.valueOf(edge.getSource()) + " ");
            toPrint = toPrint.concat(String.valueOf(edge.getDestination()) + "\n");
        }
        return toPrint;
    }
}
