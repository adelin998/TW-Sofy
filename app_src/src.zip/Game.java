import java.util.ArrayList;
import java.util.List;

public class Game extends Thread {
    private Board board;
    private Player winner;
    private final List<Player> players = new ArrayList<>();
    private List<Thread> playersThreads = new ArrayList<>();

    public void addPlayer(Player player) {
        players.add(player);
        playersThreads.add(new Thread(player));
        player.setGame(this);
    }
    //Create getters and setters

    public void setWinner() {
        int max = players.get(0).getNumberOVertices();
        Player winner = new Player("winner");
        for (Player player : players) {
            if (player.getNumberOVertices() > max) {
                max = player.getNumberOVertices();
                winner = player;
            }
        }
        this.winner = winner;
    }

    public void setWinner(Player winningPlayer) {
        int maxPoints = 0;
        this.winner = winningPlayer;
        for (Player p : players) {
            maxPoints += p.getPoints();
            p.setPoints(0);
        }
        winningPlayer.setPoints(maxPoints);
    }

    public Player getWinner() {
        return winner;
    }

    public Board getBoard() {
        return board;
    }

    public void setBoard(Board board) {
        this.board = board;
    }


    public List<Player> getPlayers() {
        return players;
    }

    public List<Thread> getPlayersThreads() {
        return playersThreads;
    }

    public void setPlayersThreads(List<Thread> playersThreads) {
        this.playersThreads = playersThreads;
    }

    //Create the method that will start the game: start one thread for each player

    /* public void start() {
         for(Player player : players){
             player.setGame(this);
             player.run();
         }

     }*/
    public void run() {

        for (Thread thread : playersThreads)
            thread.start();
    }
}
