import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class DFS {
    public static LinkedList adj(int node, Graph graph) {
        List<Edge> adjencyList = new LinkedList();
        for (Edge e : graph.getEdges()) {
            if ((e.getSource() == node) || (e.getDestination() == node))
                adjencyList.add(e);
        }
        return (LinkedList) adjencyList;
    }

    public static void DFSUtil(int v, int[] visited, Graph g) {
        visited[v] = 1;

        Iterator iterator = adj(v, g).iterator();
        while (iterator.hasNext()) {
            int n = (int) iterator.next();
            if (visited[n] == 0) {
                DFSUtil(n, visited, g);
            } else if (visited[n] == 1) {
                visited[n] = -1;
            }

        }
    }

    public static boolean isTree(Graph g) {
        int[] visited = new int[g.getNumberOfNodes()];
        DFSUtil(0, visited, g);
        for (int i = 0; i < visited.length; i++) {
            if (visited[i] == 0 || visited[i] == -1)
                return false;
        }
        return true;
    }

}