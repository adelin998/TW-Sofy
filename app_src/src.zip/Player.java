public class Player implements Runnable {
    private String name;
    private Game game;
    private Graph graph = new Graph();
    private final long THINKING_TIME = 1000; // 1 * 10^3 millisecond = 1 second
    private int points;
    private int numberOVertices;

    public Player(String name) {
        this.name = name;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public int getNumberOVertices() {
        return numberOVertices;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getPoints() {
        return points;
    }

    private void play() throws InterruptedException {
        while (game.getWinner() == null && !(game.getBoard().isEmpty())) {
            graph.add(game.getBoard().extract());
            if (this.graph.isSpanningTree()) {
                game.setWinner(this);
            }
            System.out.println(name + ": " + graph);
            Thread.sleep(THINKING_TIME);
        }
    }

    // implement the run() method, that will repeatedly extract edges
    @Override
    public void run() {
        try {
            this.play();
        } catch (InterruptedException iE) {
            System.out.println("error: " + this.name + "'s turn was interrupted");
        }
        game.setWinner();
        System.out.println(name + "  Board empty. I got " + graph.getEdges().size());
    }

    // implement the toString() method

    @Override
    public String toString() {
        return "Player{" +
                "name='" + name + '\'' +
                '}';
    }
}
