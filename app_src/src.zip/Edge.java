public class Edge {
    //Set vertexes = Collections.synchronizedSet(new HashSet<Integer>(2));
    private int source;
    private int destination;
    private static int counter = 0;
    private final int edgeNumber;

    public Edge(int source, int destination) {
        counter++;
        edgeNumber = counter;
        this.source = source;
        this.destination = destination;
    }

    public int getSource() {
        return source;
    }

    public int getDestination() {
        return destination;
    }

    public int getEdgeNumber() {
        return edgeNumber;
    }

    @Override
    public String toString() {
        return String.valueOf(edgeNumber);
    }
}
