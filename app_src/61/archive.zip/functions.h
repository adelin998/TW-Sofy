#include <string.h>
#include <stdio.h>
#include <math.h>
#include <ctype.h>

struct intVar {
	int value;
	char name[100];
	int initialized;
};

struct stringVar {
	char contains[100];
	char name[100];
	int initialized;
};


struct intVar intVars[100];
struct stringVar strings[100];


int intCounter = 0;
int stringCounter = 0;
int symbolsCounter=0;

char output[3000] = "";
char symbols[1000]="";


void rmChars(char* str, char c) {
    char *pr = str, *pw = str;
    while (*pr) {
        *pw = *pr++;
        pw += (*pw != c);
    }
    *pw = '\0';
}


void varInit(char x[],int value) {
	strcpy(intVars[intCounter].name, x);
	intVars[intCounter].initialized = 1;
	intVars[intCounter].value = value;
    char buff[100];
    sprintf(buff,"VAR: NAME=%s TYPE=integer  VALUE=%d SCOPE: global \n\n",x,value);
    strcat(symbols,buff);
	intCounter++;
}

void stringInit(char x[],char value[]) {
	strcpy(strings[stringCounter].name, x);
	strings[stringCounter].initialized = 1;
	strcpy(strings[stringCounter].contains,value);
	char buff[100];
    sprintf(buff,"VAR: NAME=%s TYPE=string  VALUE=%s SCOPE: global \n\n",x,value);
    strcat(symbols,buff);
    stringCounter++;
  
}

void varNeInit(char x[]) {
	strcpy(intVars[intCounter].name,x);
	intVars[intCounter].initialized=0;
    char buff[100];
    sprintf(buff,"VAR: NAME=%s TYPE=integer  VALUE=uninitialized SCOPE: global \n\n",x);
    strcat(symbols,buff);
	intCounter++;
}

void stringNeInit(char x[]) {
	strcpy(strings[stringCounter].name,x);
	strings[stringCounter].initialized=0;
    char buff[100];
    sprintf(buff,"VAR: NAME=%s TYPE=string  VALUE=uninitialized SCOPE: global \n\n",x);
    strcat(symbols,buff);
	stringCounter++;
}

int declared(char x[]) {
    int i;
    for(i = 0; i <= intCounter; i++)
        if(strcmp(x, intVars[i].name) == 0) return i;
    return -1;
}

int varType(char x[]) {
    int i;
    for(i = 0; i <= intCounter; i++)
        if(strcmp(x, intVars[i].name) == 0) return 0;
    for(i = 0; i <= stringCounter; i++)
        if(strcmp(x, strings[i].name) == 0) return 1;
return -1;
}
int declaredString(char x[]) {
    int i;
    for(i = 0; i <= stringCounter; i++)
        if(strcmp(x, strings[i].name) == 0) return i;
    return -1;
}

void parse(char x[], int value) {
    int position = declared(x);
    intVars[position].value = value;
    intVars[position].initialized = 1;
}

void parseString(char x[], char value[]) {
    int position = declaredString(x);
    strcpy(strings[position].contains,value);
    strings[position].initialized = 1;
}

void parsevar(char x[], char y[]) {
    int positionx = declared(x);
    int positiony = declared(y);
    intVars[positionx].value = intVars[positiony].value;
    intVars[positionx].initialized = 1;
}

void parseSstring(char x[], char y[]) {
    int positionx = declaredString(x);
    int positiony = declaredString(y);
    strcpy(strings[positionx].contains,strings[positiony].contains);
    strings[positionx].initialized = 1;
}

int initialized(char x[]) {
    int i;
    for(i = 0; i <= intCounter; i++)
        if(strcmp(x, intVars[i].name) == 0)
        	if(intVars[i].initialized == 0) return 0;
        	else return 1;
    return 0;
}

int initializedString(char x[]) {
    int i;
    for(i = 0; i <= stringCounter; i++)
        if(strcmp(x, strings[i].name) == 0)
        	if(strings[i].initialized == 0) return 0;
        	else return 1;
    return 0;
}

void write_output_int(int number) {
	char output1[30];
	sprintf(output1, "%d", number);
	strcat(output, output1);
}


void write_output_string(char value[]) {
	char buff[30];
	int a = 39;
	rmChars(value,a);
	sprintf(buff, "%s", value);
	strcat(output, buff);
}


void write_output(char text[]) {
	strcat(output, text);
}

void printInt(char x[])
{
    int position = declared(x);
    write_output_int(intVars[position].value);
    
}

void printString(char x[])
{
    int position = declaredString(x);
    write_output_string(strings[position].contains);
 
}

   void lower(char *s)
    {
          while(*s != '\0')
          {
             if (islower(*s))
                  *s = tolower(*s);
           }

    }

int maxim(int a,int b) {
	if(a>b) return a;
	else return b;
}

int minim(int a,int b) {
	if(a<b) return a;
	else return b;
}

int sqrtF(int a) {
    return a;
}





