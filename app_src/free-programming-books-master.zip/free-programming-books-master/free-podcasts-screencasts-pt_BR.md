### Index

* [Language Agnostic](#language-agnostic)


### Language Agnostic

* [Podcast] - [DevNaEstrada](http://devnaestrada.com.br)
* [Podcast] - [hipsters.tech](http://hipsters.tech)
