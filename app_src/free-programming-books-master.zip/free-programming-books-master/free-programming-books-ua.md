### Index

* [Haskell](#haskell)
* [Java](#java)
* [Language Agnostic](#language-agnostic)


### Haskell

* [Вивчить собі Хаскела на велике щастя!](http://haskell.trygub.com) - Міран Ліповача


### Java

* [Програмування мовою Java для дітей, батьків, дідусів та бабусь](http://myflex.org/books/java4kids/java4kids.htm) - Яків Файн


### Language Agnostic

* [Дизайн патерни - просто, як двері](http://designpatterns.andriybuday.com) - А. Будай
